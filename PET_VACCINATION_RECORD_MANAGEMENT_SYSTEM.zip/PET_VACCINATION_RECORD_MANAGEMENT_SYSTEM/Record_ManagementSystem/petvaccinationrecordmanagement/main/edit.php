<?php
// configuration
include('connect.php');

// new data
$pet_name = $_POST['pet_name'];
$pet_type = $_POST['pet_type'];
$gender = $_POST['gender'];
$birthday = $_POST['birthday'];
$breed = $_POST['breed'];
$color = $_POST['color'];
$weight = $_POST['weight'];
$owner = $_POST['owner'];
$doctor = $_POST['doctor'];
$date_vaccinated = $_POST['date_vaccinated'];
$id = $_POST['memids'];
// query
$sql = "UPDATE pet 
        SET pet_name=?, pet_type=?, gender=?, birthday=?, breed=?, color=?, weight=?, owner=?, doctor=?, date_vaccinated=?
		WHERE id=?";
$q = $db->prepare($sql);
$q->execute(array($pet_name,$pet_type,$gender,$birthday,$breed,$color,$weight,$owner,$doctor,$date_vaccinated,$id));
header("location: index.php");

?>