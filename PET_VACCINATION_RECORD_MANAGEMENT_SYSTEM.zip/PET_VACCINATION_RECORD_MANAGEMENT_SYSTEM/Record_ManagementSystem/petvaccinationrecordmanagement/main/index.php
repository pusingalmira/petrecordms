<style>
body {
	background: url("img/bg.png");
}
table { border-collapse: separate; background-color: #F2F3AE; border-spacing: 0; width: 85%; color: #666666; text-shadow: 0 1px 0 #FFFFFF; border: 1px solid #CCCCCC; box-shadow: 0; margin: 0 auto;font-family: arial; }
table thead tr th { background: none repeat scroll 0 0 #D58936; color: black; padding: 10px 14px; text-align: left; border-top: 0 none; font-size: 12px; }
table tbody tr td{
    background-color: #F2F3AE;
	font-size: 12px;
    text-align: left;
	padding: 10px 14px;
	border-top: 1px solid #D58936;
}
#log {
	width: 85%;
	text-align: right;
	margin: 20px auto;
	font-family: arial;
}
#log a {
	color:  #FFFFFF;
	text-decoration: none;
	font-family: arial;
}
#formdesign {
	background: linear-gradient(to bottom, #D58936 0%, #D58936 100%) repeat scroll 0 0 rgba(0, 0, 0, 0);
    border: 1px solid #D5D5D5;
    padding: 12px;
    position: relative;
	margin: 20px auto;
	width: 83%;
	clear: both;
	height: 34px;
}
#filter {
	-moz-box-sizing: border-box;
    background: url("img/big_search.png") no-repeat scroll 10px 10px #FFFFFF;
    box-shadow: none;
    display: block;
    font-size: 12px;
    height: 34px;
    padding: 9px 140px 9px 28px;display: block;
    font-size: 12px;
    height: 34px;
    padding: 9px 140px 9px 28px;
    width: 85%;
	border: 1px solid #DADADA;
    transition: border 0.2s linear 0s, box-shadow 0.2s linear 0s;
	padding-top: 6px;
	float: left;
	background-color: #F2F3AE;
}
#add {
	float: right;
	width: 8.5%;
	display: block;
    font-size: 12px;
    height: 14px;
    padding: 9px 28px 9px 28px;
	border: 1px solid #DADADA;
}
a#add {
	text-decoration: none;
	color: white;
	font-family: arial;
	font-size: 12px;
}

</style>
<script src="jscript.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<!--sa poip up-->
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
   <script src="lib/jquery.js" type="text/javascript"></script>
  <script src="src/facebox.js" type="text/javascript"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({
        loadingImage : 'src/loading.gif',
        closeImage   : 'src/closelabel.png'
      })
    })
  </script>
<div id="log">
Home | <a href="offices.php">Doctors</a> | <a href="#">Pet Owners</a> | <a href="../index.php">Logout</a>
</div>
<div id="formdesign">
<input type="text" name="filter" value="" id="filter" placeholder="Search Pet..." autocomplete="off" />
<a rel="facebox" href="add.php" id="add">Add Pet Record</a>
</div>
<table cellspacing="0" cellpadding="2" id="resultTable">
<thead>
	<tr>
		<th width="5%"> Pet ID</th>
		<th width="10%"> Pet Name</th>
		<th width="7%"> Pet Type </th>
		<th width="10%"> Gender </th>
		<th width="10%"> Birthday </th>
		<th width="15%"> Breed </th>
		<th width="10%"> Color </th>
		<th width="5%"> Weight in kg </th>
		<th width="10%"> Owner </th>
		<th width="10%"> Doctor </th>
		<th width="10%"> Date Vaccinated </th>
		<th width="10%"> Action </th>
	</tr>
</thead>
<tbody>
	<?php
		include('connect.php');		
		$result = $db->prepare("SELECT * FROM pet ORDER BY id DESC");
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>
	<tr class="record">
		<td><?php echo $row['id']; ?></td>
		<td><?php echo $row['pet_name']; ?></td>
		<td><?php echo $row['pet_type']; ?></td>
		<td><?php echo $row['gender']; ?></td>
		<td><?php echo $row['birthday']; ?></td>
		<td><?php echo $row['breed']; ?></td>
		<td><?php echo $row['color']; ?></td>
		<td><?php echo $row['weight']; ?></td>
		<td><?php echo $row['owner']; ?></td>
		<td><?php echo $row['doctor']; ?></td>
		<td><?php echo $row['date_vaccinated']; ?></td>
		<td><a rel="facebox" href="editform.php?id=<?php echo $row['id']; ?>"> Edit </a> | <a href="#" id="<?php echo $row['id']; ?>" class="delbutton" title="Click To Delete">Delete</a></td>
	</tr>
	<?php
		}
	?>
</tbody>
</table>
<script src="js/jquery.js"></script>
  <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
 if(confirm("Sure you want to delete this update? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "delete.php",
   data: info,
   success: function(){
   
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
		.animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>