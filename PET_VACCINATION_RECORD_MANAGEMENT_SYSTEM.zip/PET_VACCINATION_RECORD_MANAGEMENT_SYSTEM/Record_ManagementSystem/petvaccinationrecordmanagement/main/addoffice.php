<form action="saveoffice.php" method="post">
First Name<br>
<input type="text" name="first_name" />
<br>
Middle Name<br>
<input type="text" name="middle_name" />
<br>
Last Name<br>
<input type="text" name="last_name" />
<br>
Gender<br>
<select name="gender" class="ed">
    <option value="Male">Male</option>
    <option value="Female">Female</option>
</select><br />
Address <br>
<input type="text" name="address" />
<br>
Contact Number <br>
<input type="text" name="contact_num" />
<br><br />
<input type="submit" value="Save">
</form>