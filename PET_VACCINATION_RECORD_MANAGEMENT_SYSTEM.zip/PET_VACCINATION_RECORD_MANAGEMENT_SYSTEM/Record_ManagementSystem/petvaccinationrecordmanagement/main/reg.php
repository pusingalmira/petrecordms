<?php
include('connect.php');	

$pet_name = $_POST['pet_name'];
$pet_type = $_POST['pet_type'];
$gender = $_POST['gender'];
$birthday = $_POST['birthday'];
$breed = $_POST['breed'];
$color = $_POST['color'];
$weight = $_POST['weight'];
$owner = $_POST['owner'];
$doctor = $_POST['doctor'];
$date_vaccinated = $_POST['date_vaccinated'];

// query
$sql = "INSERT INTO pet (pet_name,pet_type,gender,birthday,breed,color,weight,owner,doctor,date_vaccinated) VALUES (:pn,:pt,:gender,:bday,:breedd,:colorr,:weightt,:ownerr,:doctorr,:dvaccinated)";
$q = $db->prepare($sql);
$q->execute(array(':pn'=>$pet_name,':pt'=>$pet_type,':gender'=>$gender,':bday'=>$birthday,':breedd'=>$breed,':colorr'=>$color,':weightt'=>$weight,':ownerr'=>$owner,':doctorr'=>$doctor,':dvaccinated'=>$date_vaccinated));
header("location: index.php");


?>