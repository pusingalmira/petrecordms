<?php
	include('connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("SELECT * FROM pet WHERE id= :userid");
	$result->bindParam(':userid', $id);
	$result->execute();
	for($i=0; $rows = $result->fetch(); $i++){
?>
<form action="edit.php" method="POST">
<input type="hidden" name="memids" value="<?php echo $id; ?>" />
Pet Name<br>
<input type="text" name="pet_name" value="<?php echo $rows['pet_name']; ?>" /><br><br>
Pet Type<br>
<select name="pet_type" class="ed">
<?php
	echo '<option value="'.$rows['pet_type'].'">'.$rows['pet_type'].'</option>';
	?>
	<option value="Cat">Cat</option>
    <option value="Dog">Dog</option>
</select><br />
Gender<br>
<select name="gender" class="ed">
<?php
	echo '<option value="'.$rows['gender'].'">'.$rows['gender'].'</option>';
	?>
	<option value="Male">Male</option>
    <option value="Female">Female</option>
</select><br />
Birthday<br>
<input type="text" name="birthday" value="<?php echo $rows['birthday']; ?>" /><br><br>
Breed<br>
<input type="text" name="breed" value="<?php echo $rows['breed']; ?>" /><br><br>
Color<br>
<input type="text" name="color" value="<?php echo $rows['color']; ?>" /><br><br>
Weight<br>
<input type="text" name="weight" value="<?php echo $rows['weight']; ?>" /><br><br>
Owner<br>
<select name="owner" class="ed">
	<?php
	echo '<option value="'.$rows['owner'].'">'.$rows['owner'].'</option>';
	include('connect.php');		
		$result = $db->prepare("SELECT * FROM owner ORDER BY id DESC");
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
		echo '<option value="'.$row[last_name].'">'.$row[last_name].'</option>';
		}
	?>
</select><br />
Doctor<br>
<select name="doctor" class="ed">
	<?php
	echo '<option value="'.$rows['doctor'].'">'.$rows['doctor'].'</option>';
	include('connect.php');		
		$result = $db->prepare("SELECT * FROM doctor ORDER BY id DESC");
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
		echo '<option value="'.$row[last_name].'">'.$row[last_name].'</option>';
		}
	?>
</select><br />
Date Vaccinated<br>
<input type="text" name="date_vaccinated" value="<?php echo $rows['date_vaccinated']; ?>" /><br><br>
<input type="submit" value="Save" />
</form>
<?php
	}
?>