<?php
// configuration
include('connect.php');

// new data
$first_name = $_POST['first_name'];
$middle_name = $_POST['middle_name'];
$last_name = $_POST['last_name'];
$gender = $_POST['gender'];
$address = $_POST['address'];
$contact_num = $_POST['contact_num'];
$id = $_POST['docId'];
// query
$sql = "UPDATE doctor 
        SET first_name=?, middle_name=?, last_name=?, gender=?, address=?, contact_num=?
		WHERE id=?";
$q = $db->prepare($sql);
$q->execute(array($first_name,$middle_name,$last_name,$gender,$address,$contact_num,$id));
header("location: offices.php");

?>