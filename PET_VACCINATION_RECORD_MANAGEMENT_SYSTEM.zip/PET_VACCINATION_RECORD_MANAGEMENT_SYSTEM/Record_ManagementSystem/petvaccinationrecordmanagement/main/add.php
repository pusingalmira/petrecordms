
<form action="reg.php" method="POST">
Pet Name<br>
<input type="text" name="pet_name" /><br>
Pet Type<br>
<select name="pet_type" class="ed">
    <option value="Cat">Cat</option>
    <option value="Dog">Dog</option>
</select><br />
Gender<br>
<select name="gender" class="ed">
    <option value="Male">Male</option>
    <option value="Female">Female</option>
</select><br />
Birthday<br>
<input type="text" placeholder="YYYY-MM-DD" name="birthday" /><br>
Breed<br>
<input type="text" name="breed" /><br>
Color<br>
<input type="text" name="color" /><br>
Weight<br>
<input type="text" name="weight" /><br>
Owner<br>
<select name="owner" class="ed">
	<?php
	include('connect.php');		
		$result = $db->prepare("SELECT * FROM owner ORDER BY id ASC");
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
		echo '<option value="'.$row[last_name].'">'.$row[last_name].'</option>';
		}
	?>
</select><br />
Doctor<br>
<select name="doctor" class="ed">
	<?php
	include('connect.php');		
		$result = $db->prepare("SELECT * FROM doctor ORDER BY id ASC");
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
		echo '<option value="'.$row[last_name].'">'.$row[last_name].'</option>';
		}
	?>
</select><br />
Date Vaccinated<br>
<input type="text" placeholder="YYYY-MM-DD" name="date_vaccinated" /><br><br>
<input type="submit" value="Save" />
</form>