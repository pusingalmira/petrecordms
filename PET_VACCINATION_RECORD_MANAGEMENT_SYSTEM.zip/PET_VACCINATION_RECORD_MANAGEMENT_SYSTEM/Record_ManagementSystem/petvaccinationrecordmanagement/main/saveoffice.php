<?php
include('connect.php');	

$first_name = $_POST['first_name'];
$middle_name = $_POST['middle_name'];
$last_name = $_POST['last_name'];
$gender = $_POST['gender'];
$address = $_POST['address'];
$contact = $_POST['contact_num'];


// query
$sql = "INSERT INTO doctor (first_name,middle_name,last_name,gender,address,contact_num) VALUES (:dfn,:dmn,:dln,:dgender,:daddress,:contactnum)";
$q = $db->prepare($sql);
$q->execute(array(':dfn'=>$first_name,':dmn'=>$middle_name,':dln'=>$last_name,':dgender'=>$gender,':daddress'=>$address, ':contactnum'=>$contact));
header("location: offices.php");


?>