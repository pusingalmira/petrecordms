<?php
	include('connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("SELECT * FROM doctor WHERE id= :userid");
	$result->bindParam(':userid', $id);
	$result->execute();
	for($i=0; $rows = $result->fetch(); $i++){
?>
<form action="savedoctor.php" method="POST">
<input type="hidden" name="docId" value="<?php echo $id; ?>" />
First Name<br>
<input type="text" name="first_name" value="<?php echo $rows['first_name']; ?>" /><br><br>
Middle Name<br>
<input type="text" name="middle_name" value="<?php echo $rows['middle_name']; ?>" /><br><br>
Last Name<br>
<input type="text" name="last_name" value="<?php echo $rows['last_name']; ?>" /><br><br>
Gender<br>
<select name="gender" class="ed">
<?php
	echo '<option value="'.$rows['gender'].'">'.$rows['gender'].'</option>';
	?>
	<option value="Male">Male</option>
    <option value="Female">Female</option>
</select><br />
Address<br>
<input type="text" name="address" value="<?php echo $rows['address']; ?>" /><br><br>
Contact Number<br>
<input type="text" name="contact_num" value="<?php echo $rows['contact_num']; ?>" /><br><br>

<input type="submit" value="Save" />
</form>
<?php
	}
?>


